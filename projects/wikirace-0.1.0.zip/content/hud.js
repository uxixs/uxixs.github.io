import { uninstallGuard } from './guard.js';

// 카드의 생김새. 남의 페이지 위에 떠 있으므로 색은 상태를 알리는 데만 쓴다.
// 왼쪽 세로 띠 하나가 진행 중(호박색)·성공(초록)·포기(흙색)를 말한다.
// 목표 제목은 위키 문서 제목과 같은 세리프로, 숫자는 고정폭으로 둔다.
const SHADOW_STYLE = `
  :host { all: initial; display: block; }
  [hidden] { display: none !important; }

  .card {
    --accent: #f0b54a;
    --accent-soft: rgba(240, 181, 74, 0.16);
    --paper: #f5f0e6;
    --dim: #9193a0;
    --line: rgba(255, 255, 255, 0.09);
    --sans: system-ui, -apple-system, "Segoe UI", "Apple SD Gothic Neo", "Malgun Gothic", sans-serif;
    --serif: "Linux Libertine", Georgia, "Times New Roman", "Apple SD Gothic Neo", "Malgun Gothic", sans-serif;
    --mono: ui-monospace, "SF Mono", "Cascadia Mono", Consolas, "Liberation Mono", monospace;

    position: relative;
    pointer-events: auto;
    box-sizing: border-box;
    width: min(92vw, 384px);
    padding: 10px 12px 9px 21px;
    border-radius: 10px;
    border: 1px solid var(--line);
    background: rgba(19, 20, 25, 0.94);
    backdrop-filter: blur(16px) saturate(1.4);
    box-shadow:
      0 1px 0 rgba(255, 255, 255, 0.05) inset,
      0 1px 2px rgba(0, 0, 0, 0.30),
      0 16px 34px -10px rgba(0, 0, 0, 0.50);
    color: var(--paper);
    font: 13px/1.35 var(--sans);
    text-align: left;
    direction: ltr;
    overflow: hidden;
    animation: appear 160ms ease-out both;
  }

  /* 상태 띠 */
  .card::before {
    content: "";
    position: absolute; left: 8px; top: 11px; bottom: 11px;
    width: 3px; border-radius: 2px;
    background: var(--accent);
    transform-origin: top;
  }

  .head {
    display: flex; align-items: center; gap: 8px;
    min-height: 16px;
  }
  .eyebrow {
    font-size: 10px; font-weight: 700;
    letter-spacing: 0.14em; text-transform: uppercase;
    color: var(--accent);
  }
  .mode {
    flex: 1; min-width: 0;
    font-size: 10px; font-weight: 600;
    letter-spacing: 0.08em; text-transform: uppercase;
    color: var(--dim);
  }
  .mode:not(:empty)::before {
    content: "";
    display: inline-block; vertical-align: middle;
    width: 10px; height: 1px; margin: -1px 8px 0 0;
    background: rgba(255, 255, 255, 0.22);
  }
  .close {
    flex: none;
    margin: -5px -5px -5px 0;
    padding: 0 0 1px; width: 22px; height: 22px;
    font-size: 16px; line-height: 1;
    color: var(--dim); background: none; border-color: transparent;
  }
  .close:hover { color: var(--paper); background: rgba(255, 255, 255, 0.10); }

  .target {
    margin-top: 3px;
    font: 400 21px/1.2 var(--serif);
    letter-spacing: 0.002em;
    color: var(--paper);
    overflow-wrap: anywhere;
    text-wrap: balance;
    /* 제목이 아무리 길어도 문서를 가리지 않게 세 줄에서 끊는다 */
    display: -webkit-box; -webkit-box-orient: vertical; -webkit-line-clamp: 3;
    overflow: hidden;
  }

  .foot {
    display: flex; align-items: center; gap: 14px;
    min-height: 26px;
    margin-top: 9px; padding-top: 8px;
    border-top: 1px solid var(--line);
  }
  .stat { display: flex; align-items: baseline; gap: 6px; white-space: nowrap; }
  .stat .label {
    font-size: 10px; font-weight: 600;
    letter-spacing: 0.1em; text-transform: uppercase;
    color: var(--dim);
  }
  .stat .value {
    font: 600 14px/1 var(--mono);
    font-variant-numeric: tabular-nums;
    color: var(--paper);
  }
  .spacer { flex: 1; }

  /* 시계가 살아 있다는 표시. 숫자는 가만히 두고 점만 천천히 숨 쉰다. */
  .live {
    align-self: center;
    width: 6px; height: 6px; margin-right: 2px; border-radius: 50%;
    background: var(--accent);
    box-shadow: 0 0 0 3px var(--accent-soft);
    animation: breathe 2.4s ease-in-out infinite;
  }

  /* 문서를 옮길 때마다 카드가 새로 그려진다. 그때 늘어난 클릭 수를 한 번 짚어준다. */
  .value.bumped { animation: bump 900ms ease-out both; }

  button {
    box-sizing: border-box;
    display: inline-flex; align-items: center; justify-content: center;
    margin: 0; height: 26px; padding: 0 11px;
    font: 600 12px/1 var(--sans);
    color: #dcdce4; background: rgba(255, 255, 255, 0.07);
    border: 1px solid rgba(255, 255, 255, 0.11);
    border-radius: 7px;
    cursor: pointer; white-space: nowrap;
    transition: background 120ms ease, color 120ms ease, border-color 120ms ease;
  }
  button:hover { background: rgba(255, 255, 255, 0.14); color: #fff; }
  button:active { transform: translateY(1px); }
  button:focus-visible { outline: 2px solid var(--accent); outline-offset: 2px; }
  button:disabled { cursor: default; opacity: 0.5; }

  /* 항복은 눈에 띄지 않게 둔다. 판을 하는 동안 누를 일이 거의 없는 버튼이다. */
  button.quiet {
    margin-right: -6px; padding: 0 8px;
    color: var(--dim); background: none; border-color: transparent;
  }
  button.quiet:hover { color: var(--paper); background: rgba(255, 255, 255, 0.08); }

  button.danger {
    color: #f3b9a3; background: rgba(222, 128, 92, 0.12);
    border-color: rgba(222, 128, 92, 0.40);
  }
  button.danger:hover { background: rgba(222, 128, 92, 0.26); color: #ffe0d3; }

  button.primary {
    color: #10140f; background: var(--accent); border-color: transparent;
  }
  button.primary:hover { color: #10140f; background: var(--accent); filter: brightness(1.1); }

  .confirm {
    display: flex; align-items: center; gap: 6px;
    animation: slide 160ms ease-out both;
  }
  .confirm-q {
    margin-right: 2px;
    font-size: 12px; font-weight: 600; color: var(--paper);
    white-space: nowrap;
  }
  /* 확인이 발치를 차지하는 동안에는 이름표를 접어 숫자만 남긴다 */
  .foot:has(.confirm) { gap: 12px; }
  .foot:has(.confirm) .stat .label { display: none; }

  /* 끝난 판. 클래스가 그림자 밖의 호스트에 붙으므로 :host()로 받는다. */
  :host(.won) .card {
    --accent: #6fdc9b;
    --accent-soft: rgba(111, 220, 155, 0.16);
    border-color: rgba(111, 220, 155, 0.34);
    background: rgba(15, 27, 22, 0.95);
    animation: land 320ms cubic-bezier(0.2, 0.9, 0.3, 1.2) both;
  }
  :host(.lost) .card {
    --accent: #d98a68;
    --accent-soft: rgba(217, 138, 104, 0.16);
    border-color: rgba(217, 138, 104, 0.26);
    background: rgba(26, 21, 20, 0.95);
  }
  :host(.won) .card::before,
  :host(.lost) .card::before { animation: draw 420ms 80ms cubic-bezier(0.2, 0.8, 0.2, 1) both; }

  /* 결과에서는 경로가 설명이 되고 숫자가 주인공이 된다 */
  :host(.won) .target,
  :host(.lost) .target { font-size: 17px; line-height: 1.25; }
  :host(.lost) .target { color: #cfc8bd; }
  :host(.won) .stat .value,
  :host(.lost) .stat .value { font-size: 16px; }
  :host(.won) .stat .value { color: var(--accent); }

  /* 성공한 순간 위쪽 모서리를 빛 한 줄이 한 번 지나간다 */
  :host(.won) .card::after {
    content: "";
    position: absolute; left: 0; top: 0; width: 100%; height: 1px;
    background: linear-gradient(90deg, transparent, var(--accent), transparent);
    transform: translateX(-100%);
    animation: sweep 900ms 120ms ease-out both;
  }

  .toast {
    pointer-events: none;
    position: absolute; left: 50%; top: calc(100% + 8px);
    transform: translateX(-50%);
    box-sizing: border-box;
    width: max-content; max-width: min(84vw, 384px);
    padding: 7px 12px 7px 24px; border-radius: 8px;
    background: rgba(19, 20, 25, 0.96);
    border: 1px solid rgba(217, 138, 104, 0.34);
    box-shadow: 0 10px 24px -8px rgba(0, 0, 0, 0.5);
    color: #f5f0e6; text-align: left;
    font: 500 12px/1.4 system-ui, -apple-system, "Segoe UI", "Apple SD Gothic Neo", "Malgun Gothic", sans-serif;
    animation: toast 1800ms ease both;
  }
  .toast::before {
    content: "";
    position: absolute; left: 10px; top: 50%;
    width: 6px; height: 6px; margin-top: -3px; border-radius: 50%;
    background: #d98a68;
  }

  @keyframes appear { from { opacity: 0; } }
  @keyframes land {
    from { opacity: 0; transform: translateY(-8px) scale(0.98); }
  }
  @keyframes draw { from { transform: scaleY(0); } }
  @keyframes sweep { to { transform: translateX(100%); } }
  @keyframes slide { from { opacity: 0; transform: translateX(6px); } }
  @keyframes breathe {
    0%, 100% { opacity: 1; box-shadow: 0 0 0 3px var(--accent-soft); }
    50% { opacity: 0.45; box-shadow: 0 0 0 1px var(--accent-soft); }
  }
  @keyframes bump {
    0%, 35% { color: var(--accent); }
  }
  @keyframes toast {
    0% { opacity: 0; transform: translate(-50%, -4px); }
    8%, 88% { opacity: 1; transform: translate(-50%, 0); }
    100% { opacity: 0; transform: translate(-50%, 0); }
  }

  @media (prefers-reduced-motion: reduce) {
    .card, .card::before, .card::after, .confirm, .live, .value.bumped, .toast {
      animation: none !important;
    }
    :host(.won) .card::after { display: none; }
  }
`;

const HOST_TAG = 'wikirace-hud';

// Cached across calls within one module instance. `host` also carries its
// own `__wikiraceTimer` property directly on the DOM element (not just in
// this module-scoped `timer` variable), so a *second* instantiation of this
// module against a document that already has a live host can still find
// and clear the previous instance's interval before it adopts that host.
let shadow = null;
let wrap = null;
let host = null;
let timer = null;

function formatDuration(ms) {
  const safeMs = Number.isFinite(ms) ? ms : 0;
  const total = Math.max(0, Math.floor(safeMs / 1000));
  const minutes = String(Math.floor(total / 60)).padStart(2, '0');
  const seconds = String(total % 60).padStart(2, '0');
  return `${minutes}:${seconds}`;
}

function ensureShadow() {
  if (shadow) return { shadow, wrap, host };

  // Adopt a pre-existing host (e.g. a stale instance of this module still
  // attached to the live document) instead of creating a second one.
  host = document.querySelector(HOST_TAG);
  if (!host) {
    host = document.createElement(HOST_TAG);
    document.documentElement.append(host);
  }
  clearInterval(host.__wikiraceTimer);
  host.__wikiraceTimer = null;
  host.classList.remove('won', 'lost');

  shadow = host.shadowRoot ?? host.attachShadow({ mode: 'open' });
  shadow.innerHTML = '';

  // The <style> lives directly in the shadow root, as a sibling of the
  // wrapper — never inside the element whose innerHTML render* replaces.
  const style = document.createElement('style');
  style.textContent = SHADOW_STYLE;
  shadow.append(style);

  wrap = document.createElement('div');
  wrap.className = 'wrap';
  shadow.append(wrap);

  return { shadow, wrap, host };
}

const MODE_LABEL = { exact: 'Exact match', partial: 'Partial match' };

function renderRunning(wrap, state, host) {
  wrap.innerHTML = `
    <div class="card">
      <div class="head">
        <span class="eyebrow">Target</span>
        <span class="mode" data-mode></span>
      </div>
      <strong class="target" data-target></strong>
      <div class="foot">
        <span class="stat"><span class="live" aria-hidden="true"></span><span class="label">Time</span><span class="value" data-clock>00:00</span></span>
        <span class="stat"><span class="label">Clicks</span><span class="value" data-clicks>0</span></span>
        <span class="spacer"></span>
        <button type="button" class="quiet" data-giveup>Give up</button>
      </div>
    </div>
  `;
  wrap.querySelector('[data-target]').textContent = state.target;
  wrap.querySelector('[data-mode]').textContent = MODE_LABEL[state.matchMode] ?? '';
  const clicks = wrap.querySelector('[data-clicks]');
  clicks.textContent = String(state.clicks ?? 0);
  clicks.classList.toggle('bumped', (state.clicks ?? 0) > 0);

  const clock = wrap.querySelector('[data-clock]');
  const tick = () => { clock.textContent = formatDuration(Date.now() - state.startedAt); };
  tick();
  timer = setInterval(tick, 500);
  host.__wikiraceTimer = timer;

  const giveupBtn = wrap.querySelector('[data-giveup]');
  // 항복은 되돌릴 수 없으므로 한 번 묻는다. 확인하는 동안에도 판은 계속
  // 돌아가고 시계도 멈추지 않는다 — 이어서 하기를 고를 수 있어야 하니까.
  giveupBtn.addEventListener('click', () => {
    const confirm = document.createElement('span');
    confirm.className = 'confirm';
    confirm.innerHTML = `
      <span class="confirm-q">Give up?</span>
      <button type="button" data-keep>Keep playing</button>
      <button type="button" class="danger" data-quit>End run</button>
    `;
    giveupBtn.replaceWith(confirm);

    confirm.querySelector('[data-keep]').addEventListener('click', () => {
      confirm.replaceWith(giveupBtn);
    });

    const quitBtn = confirm.querySelector('[data-quit]');
    quitBtn.addEventListener('click', async () => {
      quitBtn.disabled = true;
      try {
        const result = await chrome.runtime.sendMessage({ type: 'giveUp' });
        if (result?.ok) {
          renderFinished(wrap, result.record, host);
          return;
        }
        showToast('Could not end the run. Try again.');
      } catch {
        showToast('Could not end the run. Try again.');
      }
      quitBtn.disabled = false;
    });
  });
}

function renderFinished(wrap, record, host) {
  clearInterval(timer);
  host.__wikiraceTimer = null;

  // 판이 끝났으니 페이지를 사용자에게 돌려준다. 검색창이 다시 보이고 링크
  // 차단이 풀린다. 결과 카드는 사용자가 닫을 때까지 그대로 남는다.
  uninstallGuard();

  const won = record.result === 'win';
  wrap.innerHTML = `
    <div class="card">
      <div class="head">
        <span class="eyebrow" data-eyebrow></span>
        <span class="mode" data-mode></span>
        <button type="button" class="close" data-close title="Close" aria-label="Close">×</button>
      </div>
      <strong class="target" data-headline></strong>
      <div class="foot">
        <span class="stat"><span class="label">Time</span><span class="value" data-clock></span></span>
        <span class="stat"><span class="label">Clicks</span><span class="value" data-clicks></span></span>
        <span class="spacer"></span>
        <button type="button" class="primary" data-again hidden>Play again</button>
      </div>
    </div>
  `;
  host.classList.add(won ? 'won' : 'lost');

  let eyebrow;
  let headline;
  if (won) {
    eyebrow = 'Made it';
    headline = `${record.start} → ${record.target}`;
  } else if (record.result === 'abandoned') {
    eyebrow = 'Interrupted';
    headline = `The target was ${record.target}`;
  } else {
    eyebrow = 'Gave up';
    headline = `The target was ${record.target}`;
  }

  wrap.querySelector('[data-eyebrow]').textContent = eyebrow;
  wrap.querySelector('[data-headline]').textContent = headline;
  wrap.querySelector('[data-mode]').textContent = MODE_LABEL[record.matchMode] ?? '';
  wrap.querySelector('[data-clock]').textContent = formatDuration(record.durationMs);
  wrap.querySelector('[data-clicks]').textContent = String(record.clicks ?? 0);

  // 판이 끝나면 카드를 닫을 수 있어야 한다. 닫지 못하면 문서를 계속 읽고
  // 싶어도 카드가 페이지 위에 영영 남는다.
  wrap.querySelector('[data-close]').addEventListener('click', dismissHud);

  if (won) {
    const againBtn = wrap.querySelector('[data-again]');
    againBtn.hidden = false;
    // 설정은 툴바의 확장 팝업에서 고른다. 카드를 닫고 그 팝업을 열어달라고
    // 부탁한다. 브라우저가 거절하면 카드만 닫히고, 아이콘을 직접 누르면 된다.
    againBtn.addEventListener('click', () => {
      dismissHud();
      chrome.runtime.sendMessage({ type: 'openSettings' }).catch(() => {});
    });
  }
}

// 카드를 페이지에서 완전히 들어낸다. 게임은 이미 끝났으므로 다음 문서에서
// 다시 뜨지도 않는다 (content script가 진행 중인 게임이 없으면 아무것도 안 한다).
export function dismissHud() {
  clearInterval(timer);
  timer = null;
  if (host) {
    clearInterval(host.__wikiraceTimer);
    host.remove();
  }
  shadow = null;
  wrap = null;
  host = null;
}

export function mountHud(state) {
  const { wrap, host } = ensureShadow();
  clearInterval(timer);

  if (state.record) renderFinished(wrap, state.record, host);
  else renderRunning(wrap, state, host);
}

export function showToast(message) {
  const { shadow } = ensureShadow();
  shadow.querySelector('.toast')?.remove();
  const toast = document.createElement('div');
  toast.className = 'toast';
  toast.textContent = message;
  shadow.append(toast);
  setTimeout(() => toast.remove(), 1800);
}
