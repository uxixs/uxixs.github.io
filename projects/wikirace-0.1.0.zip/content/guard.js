import { classifyHref } from '../lib/link-rules.js';

const REASON_TEXT = {
  namespace: 'Locked: that is not an article link',
  external: 'Locked: you cannot leave Wikipedia',
  unsupported: 'Locked: that link is out of play',
};

// 토스트는 콜백으로 받는다. 여기서 hud를 직접 import 하면, 판이 끝났을 때
// hud가 가드를 떼려고 이 모듈을 import 하는 순간 순환 import가 된다.
let notify = () => {};
let searchStyle = null;
let installed = false;

async function goTo(href) {
  // background가 클릭 의도를 기록한 뒤에 이동해야 주소창 이동으로 오인되지 않는다.
  try {
    await chrome.runtime.sendMessage({ type: 'clickIntent' });
  } catch (error) {
    // 기록에 실패해도 이동은 시킨다. 링크가 죽어 게임을 못 하게 되는 쪽이
    // 이 한 수가 주소창 이동으로 잘못 표시되는 것보다 나쁘다.
    console.error('WikiRace: could not record the click intent', error);
  }
  location.assign(new URL(href, location.href).href);
}

function onActivate(event) {
  if (event.type === 'auxclick' && event.button !== 1) return;
  if (event.type === 'click' && event.button !== 0) return;

  const anchor = event.target instanceof Element ? event.target.closest('a[href]') : null;
  if (!anchor) return;

  const href = anchor.getAttribute('href');
  const verdict = classifyHref(href, { pageUrl: location.href });
  if (verdict.sameDocument) return;

  event.preventDefault();
  event.stopPropagation();

  if (!verdict.allowed) {
    chrome.runtime
      .sendMessage({ type: 'blocked', reason: verdict.reason })
      .catch(() => {
        // 차단 횟수는 통계일 뿐이다. 기록에 실패해도 차단 자체는 이미 끝났다.
      });
    notify(REASON_TEXT[verdict.reason] ?? REASON_TEXT.unsupported);
    return;
  }

  // 허용된 링크도 직접 이동시킨다. Ctrl+클릭이나 휠 클릭으로 새 탭이 열리면
  // 게임 탭을 벗어나 버리므로, 항상 같은 탭 이동으로 강제한다.
  goTo(href);
}

function onSubmit(event) {
  event.preventDefault();
  event.stopPropagation();
  notify('Search is locked. Follow links only.');
}

export function installGuard({ onBlocked = () => {}, searchStyle: style = null } = {}) {
  // 한 페이지에 두 번 걸리면 클릭 한 번이 두 번으로 세어진다.
  if (installed) return;
  installed = true;
  notify = onBlocked;
  searchStyle = style;
  document.addEventListener('click', onActivate, true);
  document.addEventListener('auxclick', onActivate, true);
  document.addEventListener('submit', onSubmit, true);
}

// 판이 끝나면 페이지를 사용자에게 돌려준다. 이걸 하지 않으면 승리하거나
// 항복한 뒤에도 그 페이지에서 검색창이 계속 숨겨지고 문서 외 링크가 계속
// 막히며, 그 차단 토스트가 사용자가 닫은 카드를 되살린다.
export function uninstallGuard() {
  if (!installed) return;
  installed = false;
  notify = () => {};
  document.removeEventListener('click', onActivate, true);
  document.removeEventListener('auxclick', onActivate, true);
  document.removeEventListener('submit', onSubmit, true);
  searchStyle?.remove();
  searchStyle = null;
}
