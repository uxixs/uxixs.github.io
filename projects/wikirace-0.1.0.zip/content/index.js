// MV3 content script는 ES 모듈이 될 수 없다. 이 파일은 클래식 스크립트이고,
// 실제 로직은 확장 URL로 동적 import 해서 불러온다.
(async () => {
  let state;
  try {
    state = await chrome.runtime.sendMessage({ type: 'getState' });
  } catch {
    // 확장을 리로드하면 이미 열려 있던 탭의 연결이 끊긴다. 이 페이지에서는
    // 더 할 수 있는 일이 없으니 조용히 물러난다.
    return;
  }
  if (!state || state.status !== 'running') return;

  const asset = (path) => chrome.runtime.getURL(path);
  const root = document.head || document.documentElement;

  // 검색창은 페이지가 그려지기 전에 미리 숨겨서 깜빡임을 없앤다.
  // 판이 끝나면 가드가 이 요소를 다시 걷어낸다.
  const hideSearch = document.createElement('style');
  hideSearch.textContent = `
    #p-search, #searchform, #simpleSearch,
    .vector-search-box, .vector-search-box-vue, .cdx-typeahead-search { display: none !important; }
  `;
  root.append(hideSearch);

  const hudStyles = document.createElement('link');
  hudStyles.rel = 'stylesheet';
  hudStyles.href = asset('content/hud.css');
  root.append(hudStyles);

  try {
    if (document.readyState === 'loading') {
      await new Promise((resolve) => {
        document.addEventListener('DOMContentLoaded', resolve, { once: true });
      });
    }

    const [guard, hud, tracker] = await Promise.all([
      import(asset('content/guard.js')),
      import(asset('content/hud.js')),
      import(asset('content/tracker.js')),
    ]);

    guard.installGuard({ onBlocked: hud.showToast, searchStyle: hideSearch });

    // 현재 문서를 background에 알리고, 돌아온 상태로 카드를 다시 그린다.
    const sync = async () => {
      let next;
      try {
        next = await tracker.reportArrival();
      } catch {
        next = null;
      }
      if (!next) {
        // 판이 이미 끝났거나 확장과 끊겼다. 페이지를 원래대로 돌려준다.
        guard.uninstallGuard();
        hud.dismissHud();
        return;
      }
      hud.mountHud(next);
    };

    await sync();

    // 뒤로/앞으로 가기는 보통 bfcache 복원이라 content script가 다시 실행되지
    // 않는다. 그러면 도착이 보고되지 않아 그 한 수가 세어지지 않고, 돌아간
    // 곳이 목표 문서였더라도 승리가 잡히지 않는다. 복원될 때 다시 보고한다.
    window.addEventListener('pageshow', (event) => {
      if (event.persisted) sync();
    });
  } catch (error) {
    hideSearch.remove();
    hudStyles.remove();
    console.error('WikiRace: Failed to initialize game overlay', error);
  }
})();
