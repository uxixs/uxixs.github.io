import { normalizeTitle } from '../lib/title.js';

const ARTICLE_PATH = '/wiki/';

function titleFromPath(pathname) {
  if (!pathname.startsWith(ARTICLE_PATH)) return '';
  return normalizeTitle(pathname.slice(ARTICLE_PATH.length));
}

// 리다이렉트 문서를 열면 주소는 리다이렉트 제목 그대로 남는다.
// canonical 링크만이 정식 제목을 알려준다.
export function titleFromCanonical(doc, fallbackPath) {
  const canonical = doc.querySelector('link[rel="canonical"]');
  if (canonical?.href) {
    try {
      const title = titleFromPath(new URL(canonical.href).pathname);
      if (title) return title;
    } catch {
      // canonical이 URL로 파싱되지 않으면 주소 경로로 넘어간다.
    }
  }
  return titleFromPath(fallbackPath);
}

export function currentTitle() {
  return titleFromCanonical(document, location.pathname);
}

export async function reportArrival() {
  return chrome.runtime.sendMessage({ type: 'arrived', title: currentTitle() });
}
