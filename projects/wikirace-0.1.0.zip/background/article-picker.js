import { fetchRandomBatch, fetchLinkCounts, isRateLimited } from '../lib/wiki-api.js';
import { rankCandidates } from '../lib/article-filter.js';
import { sameArticle } from '../lib/title.js';
import { languageFor, DEFAULT_LANG } from '../lib/languages.js';

export const MIN_OUTGOING = 50;
export const MIN_INCOMING = 50;
// 한 번에 100개를 받으면 품질 필터를 넘는 후보가 보통 열 개 넘게 나와,
// 대개 배치 한 번으로 끝난다. 20개씩 네 번 긁던 예전 방식은 요청만 많고
// 후보는 모자라 위키의 속도 제한(429)을 자초했다.
export const BATCH_SIZE = 100;

// 검색 생성기(gsrlimit)는 한 번에 50개까지만 준다. 무작위 생성기보다 적지만
// 주제 검색은 매번 꽉 채워 오므로 배치를 모으면 충분하다.
export const TOPIC_BATCH_SIZE = 50;

// 링크 수 조회는 제목 하나당 요청 하나다 (pllimit/lhlimit이 페이지별이 아니라
// 질의 전체에 걸리므로 여러 제목을 한 번에 물으면 수가 뒤섞인다). 시작이
// 느려지지 않도록 한 판에 거는 조회 수를 묶어둔다.
const MAX_LINK_LOOKUPS = 10;

function seedPair(lang, random) {
  const seeds = languageFor(lang).seeds;
  const startIndex = Math.floor(random() * seeds.length);
  const offset = 1 + Math.floor(random() * (seeds.length - 1));
  const targetIndex = (startIndex + offset) % seeds.length;
  return {
    start: seeds[startIndex],
    target: seeds[targetIndex],
    source: 'seed',
  };
}

// 조회수를 아는 문서를 앞에, 모르는 문서를 뒤에. 배치가 쌓여도 전체가 이
// 순서를 유지해야 "유명한 곳에서 덜 유명한 곳으로" 방향이 지켜진다.
function byRank(a, b) {
  if (a.views === null && b.views === null) return 0;
  if (a.views === null) return 1;
  if (b.views === null) return -1;
  return b.views - a.views;
}

// 링크 수를 한 번만 조회하고 기억한다. 조회에 실패했거나 예산을 다 썼으면
// null이고, 그 문서는 이번 판에서 쓰지 않는다.
function createLinkCounter(fetchImpl, lang) {
  const known = new Map();
  let lookups = 0;
  let limited = false;
  const countsFor = async (title) => {
    if (known.has(title)) return known.get(title);
    if (limited || lookups >= MAX_LINK_LOOKUPS) return null;
    lookups += 1;
    try {
      const counts = await fetchLinkCounts(fetchImpl, title, lang);
      known.set(title, counts);
      return counts;
    } catch (error) {
      // 속도 제한에 걸렸으면 남은 후보를 더 물어봐야 전부 막힌다.
      if (isRateLimited(error)) limited = true;
      known.set(title, null);
      return null;
    }
  };
  countsFor.isLimited = () => limited;
  return countsFor;
}

// 모아둔 후보에서 조건을 만족하는 첫 쌍을 찾는다. 목표는 출발보다 뒤 순위에서
// 고른다.
async function findViablePair(pool, countsFor) {
  for (let i = 0; i < pool.length; i += 1) {
    const start = await countsFor(pool[i].title);
    if (!start || start.outgoing < MIN_OUTGOING) continue;

    for (let j = i + 1; j < pool.length; j += 1) {
      const target = await countsFor(pool[j].title);
      if (!target || target.incoming < MIN_INCOMING) continue;
      return { start: pool[i].title, target: pool[j].title };
    }
  }
  return null;
}

function addToPool(pool, pages, lang, exclude = null) {
  for (const { page, views } of rankCandidates(pages, lang)) {
    if (exclude && sameArticle(page.title, exclude)) continue;
    if (pool.some((c) => c.title === page.title)) continue;
    pool.push({ title: page.title, views });
  }
  pool.sort(byRank);
}

export async function pickArticlePair({
  lang = DEFAULT_LANG,
  topicQuery = null,
  fetchImpl = fetch,
  maxBatches = 4,
  random = Math.random,
} = {}) {
  // 무작위 50개 중 품질 필터를 넘는 것은 평균 두어 개뿐이다. 배치마다 쌍을
  // 요구하고 실패하면 그 후보들을 버리면, 대부분의 판이 아래 시드로 떨어진다.
  // 그래서 후보를 배치 너머로 모아두고, 쌓일 때마다 쌍을 다시 찾는다.
  const pool = [];
  const countsFor = createLinkCounter(fetchImpl, lang);
  // 검색 배치는 무작위 배치의 절반 크기라, 주제 판은 배치를 조금 더 쓴다.
  const batchSize = topicQuery ? TOPIC_BATCH_SIZE : BATCH_SIZE;
  const budget = topicQuery ? maxBatches + 2 : maxBatches;

  for (let attempt = 0; attempt < budget; attempt += 1) {
    let pages;
    try {
      pages = await fetchRandomBatch(fetchImpl, batchSize, lang, topicQuery);
    } catch (error) {
      // 속도 제한은 몇 초 안에 풀리지 않는다. 더 때려봐야 같은 429만 받고
      // 제한만 길어지므로 바로 그만둔다. 다른 오류는 재시도한다.
      if (isRateLimited(error)) break;
      continue;
    }

    addToPool(pool, pages, lang);

    const pair = await findViablePair(pool, countsFor);
    if (pair) return { ...pair, source: 'random' };
    if (countsFor.isLimited()) break;
  }

  // 시드 문서는 주제와 무관하다. 주제를 고른 판에서 시드를 내주면 고른 대로
  // 안 되는 셈이므로, 그때는 못 찾았다고 알린다.
  if (topicQuery) return null;
  return seedPair(lang, random);
}

function seedTargetFor(startTitle, lang, random) {
  const seeds = languageFor(lang).seeds;
  const offset = Math.floor(random() * seeds.length);
  for (let i = 0; i < seeds.length; i += 1) {
    const candidate = seeds[(offset + i) % seeds.length];
    if (!sameArticle(candidate, startTitle)) return candidate;
  }
  return seeds[0];
}

// 출발 문서가 이미 정해진 판(현재 보고 있는 문서에서 시작)에서 목표만 고른다.
export async function pickTargetFor(startTitle, {
  lang = DEFAULT_LANG,
  topicQuery = null,
  fetchImpl = fetch,
  maxBatches = 4,
  random = Math.random,
} = {}) {
  const pool = [];
  const countsFor = createLinkCounter(fetchImpl, lang);
  const batchSize = topicQuery ? TOPIC_BATCH_SIZE : BATCH_SIZE;

  for (let attempt = 0; attempt < maxBatches; attempt += 1) {
    let pages;
    try {
      pages = await fetchRandomBatch(fetchImpl, batchSize, lang, topicQuery);
    } catch (error) {
      if (isRateLimited(error)) break;
      continue;
    }

    addToPool(pool, pages, lang, startTitle);

    for (const candidate of pool) {
      const counts = await countsFor(candidate.title);
      if (counts && counts.incoming >= MIN_INCOMING) {
        return { target: candidate.title, source: 'random' };
      }
    }
    if (countsFor.isLimited()) break;
  }

  if (topicQuery) return null;
  return { target: seedTargetFor(startTitle, lang, random), source: 'seed' };
}
