import { withNewRecord } from '../lib/records.js';

const ACTIVE_GAME = 'activeGame';
const RECORDS = 'records';

export async function getActiveGame() {
  const stored = await chrome.storage.local.get(ACTIVE_GAME);
  return stored[ACTIVE_GAME] ?? null;
}

export async function setActiveGame(state) {
  await chrome.storage.local.set({ [ACTIVE_GAME]: state });
  return state;
}

export async function clearActiveGame() {
  await chrome.storage.local.remove(ACTIVE_GAME);
}

export async function getRecords() {
  const stored = await chrome.storage.local.get(RECORDS);
  return stored[RECORDS] ?? [];
}

export async function pushRecord(record) {
  const next = withNewRecord(await getRecords(), record);
  await chrome.storage.local.set({ [RECORDS]: next });
  return next;
}
