import { pickArticlePair, pickTargetFor } from './article-picker.js';
import { normalizeTitle, isArticleTitle } from '../lib/title.js';
import { articleUrl, langFromHost, isSupportedLang, DEFAULT_LANG } from '../lib/languages.js';
import { topicQuery, topicLabel, isSupportedTopic, DEFAULT_TOPIC } from '../lib/topics.js';
import {
  createGame, markClickIntent, recordArrival, recordBlocked, toRecord,
} from '../lib/game-reducer.js';
import { submitRecord } from '../lib/sync.js';
import * as store from './storage.js';

// 탭 주소가 지원하는 위키의 일반 문서면 {lang, title}을, 아니면 null을 준다.
function articleRefFromUrl(rawUrl) {
  if (!rawUrl) return null;
  let url;
  try {
    url = new URL(rawUrl);
  } catch {
    return null;
  }
  if (url.protocol !== 'https:') return null;
  const lang = langFromHost(url.hostname);
  if (!lang) return null;
  if (!url.pathname.startsWith('/wiki/')) return null;
  const title = normalizeTitle(url.pathname.slice('/wiki/'.length));
  return isArticleTitle(title, lang) ? { lang, title } : null;
}

async function finish(state, result) {
  const record = toRecord(state, { result, now: Date.now() });
  await store.pushRecord(record);
  await store.clearActiveGame();
  await submitRecord(record);
  return record;
}

// 직렬화기: 프로미스 체인 하나로 모든 핸들러 호출을 순서대로 실행한다.
// 이렇게 하면 특정 시점에 최대 하나의 핸들러 본문만 실행 중이므로, 두 메시지가
// 서로의 read-compute-write 사이에 끼어들어 상태를 덮어쓰는 경합이 생기지 않는다.
// (예: clickIntent 직후 도착하는 arrived, 또는 같은 승리를 두 번 관찰하는 arrived 두 개.)
// 체인 자체는 절대 reject하지 않도록 감싸서, 한 핸들러의 실패가 이후 메시지들의
// 실행을 막는 "체인 오염"을 일으키지 않게 한다.
let tail = Promise.resolve();
function serialize(task) {
  const result = tail.then(task, task);
  tail = result.then(
    () => undefined,
    () => undefined,
  );
  return result;
}

const handlers = {
  async startGame({ lang: requestedLang, topic: requestedTopic, matchMode, startFrom = 'random' }) {
    // 실패할 수 있는 일을 먼저 끝낸다: 활성 탭을 찾고 문서를 고르는 데 성공한
    // 뒤에야 기존 게임을 정리한다. 그래야 시작이 실패해도 진행 중인 판이 이미
    // abandoned로 지워지는 일이 없다.
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab) return { ok: false, error: 'no active tab' };

    let lang = isSupportedLang(requestedLang) ? requestedLang : DEFAULT_LANG;
    const topic = isSupportedTopic(requestedTopic) ? requestedTopic : DEFAULT_TOPIC;
    const query = topicQuery(topic);
    // 주제를 골랐는데 못 찾으면 시드로 때우지 않고 그렇다고 알린다.
    const noMatch = { ok: false, error: `no ${topicLabel(topic)} articles came up — try again` };

    let start;
    let target;
    if (startFrom === 'current') {
      // 지금 보고 있는 문서에서 시작할 때는 그 문서의 언어판을 따른다.
      // 팝업에서 고른 언어보다 눈앞의 탭이 더 분명한 의사표시다.
      const ref = articleRefFromUrl(tab.url);
      if (!ref) {
        return { ok: false, error: 'open a Wikipedia article first' };
      }
      lang = ref.lang;
      start = ref.title;
      try {
        const found = await pickTargetFor(start, { lang, topicQuery: query });
        if (!found) return noMatch;
        ({ target } = found);
      } catch (error) {
        return { ok: false, error: String(error) };
      }
    } else {
      try {
        const found = await pickArticlePair({ lang, topicQuery: query });
        if (!found) return noMatch;
        ({ start, target } = found);
      } catch (error) {
        return { ok: false, error: String(error) };
      }
    }

    const active = await store.getActiveGame();
    if (active) await finish(active, 'abandoned');

    const state = createGame({
      id: crypto.randomUUID(),
      start,
      target,
      lang,
      topic,
      matchMode,
      startFrom,
      tabId: tab.id,
      now: Date.now(),
    });
    await store.setActiveGame(state);

    if (startFrom === 'current') {
      // 이미 출발 문서 위에 있다. 다시 불러와야 content script가 새 게임을 본다.
      await chrome.tabs.reload(tab.id);
    } else {
      await chrome.tabs.update(tab.id, { url: articleUrl(state.lang, state.start) });
    }
    return { ok: true, state };
  },

  async getState(_msg, sender) {
    const state = await store.getActiveGame();
    if (!state) return null;
    // 게임은 시작한 탭 하나에만 묶인다. 다른 탭에서는 HUD도 규칙도 걸지 않는다.
    if (sender?.tab && sender.tab.id !== state.tabId) return null;
    return state;
  },

  async clickIntent(_msg, sender) {
    const state = await store.getActiveGame();
    if (!state || sender?.tab?.id !== state.tabId) return { ok: false };
    await store.setActiveGame(markClickIntent(state));
    return { ok: true };
  },

  async arrived({ title }, sender) {
    const state = await store.getActiveGame();
    if (!state || sender?.tab?.id !== state.tabId) return null;

    const next = recordArrival(state, { title, now: Date.now() });
    if (next.status === 'won') {
      const record = await finish(next, 'win');
      // 승리 시 반환값은 상태 그대로가 아니라 record 필드가 합쳐진 형태다.
      // 인페이지 오버레이가 결과 카드를 그리는 데 이 record를 그대로 쓰므로
      // 이 모양을 함부로 바꾸면 안 된다.
      return { ...next, record };
    }
    await store.setActiveGame(next);
    return next;
  },

  async blocked(_msg, sender) {
    const state = await store.getActiveGame();
    if (!state || sender?.tab?.id !== state.tabId) return { ok: false };
    await store.setActiveGame(recordBlocked(state));
    return { ok: true };
  },

  async giveUp(_msg, sender) {
    const state = await store.getActiveGame();
    // 다른 핸들러와 동일한 탭 바인딩 규칙: sender에 탭이 있는데 게임이 묶인
    // 탭과 다르면 거절한다. 확장 페이지처럼 탭이 없는 sender는 그대로 통과시킨다.
    if (!state || (sender?.tab && sender.tab.id !== state.tabId)) return { ok: false };
    return { ok: true, record: await finish(state, 'giveup') };
  },

  // 툴바 팝업을 대신 열어준다. 브라우저가 거절할 수 있는 호출이라
  // 실패해도 조용히 넘긴다 — 그때는 사용자가 직접 아이콘을 누르면 된다.
  async openSettings() {
    try {
      await chrome.action.openPopup();
      return { ok: true };
    } catch (error) {
      return { ok: false, error: String(error) };
    }
  },

  async getRecords() {
    return store.getRecords();
  },
};

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  // Object.prototype에 있는 속성(constructor, toString 등)까지 찾아지는 것을
  // 막기 위해 hasOwnProperty로 이 모듈이 실제로 정의한 핸들러만 매칭한다.
  const type = message?.type;
  if (typeof type !== 'string' || !Object.hasOwn(handlers, type)) return false;
  const handler = handlers[type];
  serialize(() => handler(message, sender)).then(
    sendResponse,
    (error) => sendResponse({ ok: false, error: String(error) }),
  );
  return true; // 비동기 응답을 쓰겠다는 신호
});

chrome.tabs.onRemoved.addListener((tabId) => serialize(async () => {
  const state = await store.getActiveGame();
  if (state && state.tabId === tabId) await finish(state, 'abandoned');
}));
