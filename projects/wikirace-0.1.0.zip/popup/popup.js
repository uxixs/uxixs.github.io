import {
  LANGUAGE_OPTIONS, TOPIC_OPTIONS, START_FROM_OPTIONS, MATCH_OPTIONS, DEFAULTS,
  MATCH_HINT, START_FROM_HINT, fillSelect,
} from '../lib/options.js';

const startButton = document.querySelector('#start');
const matchSelect = document.querySelector('#match');
const startFromSelect = document.querySelector('#startFrom');
const langSelect = document.querySelector('#lang');
const topicSelect = document.querySelector('#topic');
const hintLine = document.querySelector('#hint');
const statusLine = document.querySelector('#status');
const recordList = document.querySelector('#records');

function formatDuration(ms) {
  const total = Number.isFinite(ms) ? Math.max(0, Math.floor(ms / 1000)) : 0;
  return `${Math.floor(total / 60)}m ${String(total % 60).padStart(2, '0')}s`;
}

const RESULT_TEXT = { win: 'Won', giveup: 'Gave up', abandoned: 'Interrupted' };
const MATCH_TEXT = { exact: 'exact', partial: 'partial' };

fillSelect(langSelect, LANGUAGE_OPTIONS, DEFAULTS.lang);
fillSelect(topicSelect, TOPIC_OPTIONS, DEFAULTS.topic);
fillSelect(startFromSelect, START_FROM_OPTIONS, DEFAULTS.startFrom);
fillSelect(matchSelect, MATCH_OPTIONS, DEFAULTS.matchMode);

function renderControls() {
  // 현재 문서에서 시작하면 그 탭의 언어판을 따르므로 여기서 고른 언어는 쓰이지 않는다.
  langSelect.disabled = startFromSelect.value === 'current';

  const hints = [
    START_FROM_HINT[startFromSelect.value],
    MATCH_HINT[matchSelect.value],
  ];
  hintLine.textContent = hints.filter(Boolean).join(' ');
}

function emptyRow(text) {
  const item = document.createElement('li');
  item.className = 'meta';
  item.textContent = text;
  return item;
}

const VISIBLE_RECORDS = 3;

function recordRow(record) {
  const item = document.createElement('li');
  const pair = document.createElement('span');
  pair.className = 'pair';
  pair.textContent = `${record.start} → ${record.target}`;
  const meta = document.createElement('span');
  meta.className = `meta ${record.result}`;
  // 채점 기준이 없는 기록은 이 설정이 생기기 전에 만들어진 것이다.
  const mode = MATCH_TEXT[record.matchMode];
  const parts = [
    RESULT_TEXT[record.result] ?? record.result,
    ...(mode ? [mode] : []),
    formatDuration(record.durationMs),
    `${record.clicks ?? 0} clicks`,
  ];
  meta.textContent = parts.join(' · ');
  item.append(pair, meta);
  return item;
}

async function renderRecords() {
  let records;
  try {
    records = await chrome.runtime.sendMessage({ type: 'getRecords' });
  } catch (error) {
    console.error('WikiRace: could not read the records', error);
    recordList.replaceChildren(emptyRow('Could not read the records'));
    return;
  }

  recordList.replaceChildren();
  if (!records?.length) {
    recordList.append(emptyRow('No runs yet'));
    return;
  }

  for (const record of records.slice(0, VISIBLE_RECORDS)) {
    recordList.append(recordRow(record));
  }

  const rest = records.slice(VISIBLE_RECORDS);
  if (rest.length === 0) return;

  // 나머지는 접어둔다. 팝업은 좁아서 목록이 길면 다른 것이 안 보인다.
  const hidden = rest.map((record) => {
    const row = recordRow(record);
    row.hidden = true;
    recordList.append(row);
    return row;
  });

  const toggleRow = document.createElement('li');
  toggleRow.className = 'toggle-row';
  const toggle = document.createElement('button');
  toggle.type = 'button';
  toggle.className = 'link';
  let open = false;
  const sync = () => {
    for (const row of hidden) row.hidden = !open;
    toggle.textContent = open ? 'Show less' : `Show ${rest.length} more`;
    toggle.setAttribute('aria-expanded', String(open));
  };
  toggle.addEventListener('click', () => { open = !open; sync(); });
  sync();
  toggleRow.append(toggle);
  recordList.append(toggleRow);
}

async function renderStatus() {
  let state;
  try {
    state = await chrome.runtime.sendMessage({ type: 'getState' });
  } catch (error) {
    console.error('WikiRace: could not read the game state', error);
    return;
  }

  if (state?.status === 'running') {
    statusLine.textContent = `In progress: ${state.start} → ${state.target}`;
    startButton.textContent = 'New run';
  } else {
    statusLine.textContent = '';
    startButton.textContent = 'Start';
  }
}

startButton.addEventListener('click', async () => {
  startButton.disabled = true;
  statusLine.textContent = 'Picking articles...';

  let result;
  try {
    result = await chrome.runtime.sendMessage({
      type: 'startGame',
      lang: langSelect.value,
      topic: topicSelect.value,
      matchMode: matchSelect.value,
      startFrom: startFromSelect.value,
    });
  } catch (error) {
    result = { ok: false, error: String(error) };
  }

  if (result?.ok) {
    window.close();
    return;
  }
  // 버튼을 다시 살려두지 않으면 팝업을 닫았다 열기 전까지 재시도할 수 없다.
  startButton.disabled = false;
  statusLine.textContent = `Could not start: ${result?.error ?? 'unknown error'}. Press again.`;
});

matchSelect.addEventListener('change', renderControls);
langSelect.addEventListener('change', renderControls);
startFromSelect.addEventListener('change', renderControls);

renderControls();
renderStatus();
renderRecords();
